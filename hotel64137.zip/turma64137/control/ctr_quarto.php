<?php 
    require_once '../model/quarto.php';
    $objQuarto = new Quarto();

    if(isset($_POST['insert'])){        
        $descricao  = $_POST['txtdescricao'];
        $status = $_POST['txtstatus'];
        $valor  = $_POST['txtvalor'];       
        if($objQuarto->insert($descricao, $status, $valor)){
            $objQuarto->redirect('../view/quarto.php');
        }
    }

    if(isset($_GET['delete_id'])){
        $id = $_GET['delete_id'];
        if($objQuarto->delete($id)){
            $objQuarto->redirect('../view/quarto.php');
        }
    }
    if(isset($_POST['txtEditar'])){
        $id = $_POST['txtEditar'];
        $descricao = $_POST['txtdescricao'];
        $status = $_POST['txtstatus'];
        $valor = $_POST['txtvalor'];
        if($objQuarto->update($descricao, $status, $valor, $id)){
            $objQuarto->redirect('../view/quarto.php');
        }      
    }
?>