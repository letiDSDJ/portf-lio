using System;
using System.Collections.Generic;
using System.Text;
namespace RPG
{
    public class Local
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
    }
}