using System;
using System.Collections.Generic;
using System.Text;
namespace RPG
{
    public class Busca
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public int XpRecompensa { get; set; }
        public int RecompensaOuro { get; set; }
    }
}