namespace RPG
{
    public class Pocoes
    {
        public int ID { get; set; }
        public string Nome  { get; set; }
        public string NomePlural { get; set; }
        public int QuantidadeCura { get; set; }

        // Método especial (Construtor) tem que ter mesmo nome da classe
        public Pocoes(string nome, string nomePlural)
        {
            Nome = nome;
            NomePlural = nomePlural;
            
        }
        public Pocoes(string nome, string nomePlural, int QuantidadeCura)
        {
            Nome = nome;
            NomePlural = nomePlural;
        }
    }
}