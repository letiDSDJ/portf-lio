// FONTE: Site de Prof. Scott Lilly
/*
    Quais são as classes/objetos em nosso jogo?

    Uma maneira fácil de descobrir quais serão seus objetos é escrever o que
     você quer que seu programa faça e sublinhar todos os substantivos. 
     Para o nosso jogo, queremos fazer estas coisas:

    - O jogador vai para locais.
    - O jogador pode precisar ter certos itens para entrar em um local.
    - O local pode ter uma missão disponível.
    - Para completar uma missão, o jogador deve coletar certos itens e entregá-los.
    - O jogador pode coletar itens indo a um local e lutando contra monstros lá.
    - O jogador luta contra monstros com armas.
    - O jogador pode usar uma poção de cura enquanto luta.
    - O jogador recebe itens de saque depois de derrotar um monstro.
    - Depois de entregar a missão, o jogador recebe itens de recompensa.
    
    Assim, os substantivos (classes/objetos) neste jogo serão:
        o Jogador
        o Localização
        o Item
        o Busca
        o Monstro
        o Arma
        o Poção
        o Entre outras...
 

    Qual é a diferença entre uma classe e um objeto?
     Uma classe é basicamente um formulário em branco, ou blueprint, para 
     um objeto. Ele define o objeto, mas não é o objeto.
    Pense nos dias de jogar Dungeons & Dragons. Quando você tinha fichas de 
     personagens no papel.
    A ficha de personagem em branco tem espaços para o nome do seu personagem,
     classe, nível, pontos de experiência, atributos, armaduras, armas, 
     inventário, habilidades, feitiços, etc. Mas, até você preencher esses 
     espaços, era apenas um esboço (uma classe) .
    Depois de preencher as informações do seu personagem, você tinha um 
     personagem (um objeto).
    Pensando em coisas físicas, a planta de uma casa é uma aula (diz como
     será a casa). Uma vez que você tenha construtores seguindo o projeto,
     com madeira, aço, concreto, etc., você terá uma casa (o objeto).


    Resumo
    -------
    “Você não está escrevendo um programa para o computador ler. Você está escrevendo
     um programa para um programador ler.”

    Etapa 1:
    Criar a classe Jogador:
        Atributos:
        . PontosVida
        . MaxPontosVidas 
        . Ouro 
        . PontosExperiencia
        . Nivel
    
    Etapa 2:
    Criar a classe Itens:
        Atributos:
        . ID
        . Nome
        . NomePlural
*/
