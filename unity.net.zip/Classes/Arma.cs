using System;
using System.Collections.Generic;
using System.Text;
namespace Engine
{
    public class Armas
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string NomePlural { get; set; }
        public int DanoMinimo { get; set; }
        public int DanoMaximo { get; set; }
    }
}