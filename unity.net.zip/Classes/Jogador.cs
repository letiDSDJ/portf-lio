using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG
{
    // A classe Jogador é pública
    // Pode ser vista por qq outra classe
    public class Jogador
    {
        // Os métodos abaixo tbm são visíveis para qualquer
        //  Classe externa, pois são, públicos (Escopo)
        public int PontosVida { get; set; }
        public int MaxPontosVidas { get; set; }
        public int Ouro { get; set; }
        public int PontosExperiencia { get; set; }
        public int Nivel { get; set; }
    }
}