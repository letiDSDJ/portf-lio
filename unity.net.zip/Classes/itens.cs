using System;
using System.Collections.Generic;
using System.Text;
namespace RPG
{
    public class Itens
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string NomePlural { get; set; }
        
        public Itens(string nome, string nomePlural)
        {
            Nome = nome;
            NomePlural = nomePlural;
        }
    }
}
 