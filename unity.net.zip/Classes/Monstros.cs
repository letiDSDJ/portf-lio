using System;
using System.Collections.Generic;
using System.Text;
namespace RPG
{
    public class Monstros
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public int MaxPontosVida { get; set; }
        public int PontosVida { get; set; }
        public int DanoMaximo { get; set; }
        public int XpRecompensa { get; set; }
        public int RecompensaOuro { get; set; }
    }
}