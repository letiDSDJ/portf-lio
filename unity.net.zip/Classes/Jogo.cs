using System.Reflection;
using RPG;

namespace Jogo
{
    public class AventuraComecaAqui
    {       
        static void Main()
        {
            // Aqui estamos instanciando um objeto Jogador e atribuíndo
            // a variável 'antonio', uma variável privada.
            Jogador antonio = new Jogador();
            // Carregando os atributos com valores no objeto...
            antonio.PontosVida = 10;
            antonio.MaxPontosVidas = 10;
            antonio.Ouro = 20;
            antonio.pontosExperiencia = 0;
            antonio.Nivel = 1;
            Console.WriteLine( new string('*', 40));
            Console.WriteLine("Jogo iniciando em {0}", DateTime.Now.ToString());
            Console.WriteLine( new string('*', 40) + "\n");
            
            // Este foreach (loop) poderia ser substituído por:
            // Console.WriteLine("{0}",antonio.PontosVidas);
            // ...
            foreach(PropertyInfo atrib in antonio.GetType().GetProperties())
            {
                Console.WriteLine("{0} : {0}", atrib.Name, atrib.GetValue(antonio));
            }
        }
    }
}
