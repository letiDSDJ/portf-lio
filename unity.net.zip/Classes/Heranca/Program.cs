﻿public class programa
{
    
    public static void Main()
    {
        Filha obj = new Filha();
        obj.Imprimir();
        Console.WriteLine(obj.Idade);
        obj.Idade = 150;
        Console.WriteLine(obj.Idade);

        Peixes objPeixe = new Peixes();
        Elefantes objElef = new Elefantes();
        objPeixe.Locomover();
        objElef.Locomover();
    }
}

public class Mae
{
    private int _idade = 10;
    
    public int Idade
    {
        get {return _idade;}
        set {
                if(value<=150 && value>0)
                    _idade = value;
            }
    }
    
    public void Imprimir()
    {
        Console.WriteLine ("Classe Mae");
    }
}


public class Filha:Mae
{
    public new void Imprimir()
    {
        base.Imprimir();
    }
}

public class Animais
{
    public virtual void Locomover()
    {
        Console.WriteLine("Método de Locomoção: ");
    }
}

public class Passaros:Animais
{
    public new void Locomover()
    {
        Console.WriteLine("Pássaro Voa");
    }
}

public class Elefantes:Animais
{
    public override void Locomover()
    {
        Console.WriteLine("Elefante Anda");
    }
}

public class Peixes:Animais
{
    public new void Locomover()
    {
        Console.WriteLine("Peixe Nada");
    }
}