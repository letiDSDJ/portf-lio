﻿/*
    1) Crie a classe Abstrata 'Animais' e suas 'Filhas', 'Caes' e 'Passaros'.
    Tente criar uma instância para 'Animais', 'Caes' e 'Passaros,
    o quê acontece?

    2) Agora crie os protótipos de métodos para a classe Base 'Animais'
    chamados de 'Locomover()' e 'Soar()'
    
    3) Implemente na classe 'Caes', 'Passaros'  e 'Peixes' os métodos
       'Locomover()' e 'Soar()'.

*/

public class Teste
{
    public static void Main()
    {
        
    } 
}











































/*


public abstract class Animais
{
    public abstract void Locomover();
    public abstract void Soar();
}

public class Caes:Animais
{
    override public void Locomover()
    {
        
        
        
            Console.WriteLine("Voam");
        
    }
}
*/