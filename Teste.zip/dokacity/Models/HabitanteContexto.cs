using Microsoft.EntityFrameworkCore;
namespace dokacity.Models

{
    public class HabitanteContexto : DbContext
    {
        public HabitanteContexto(DbContextOptions<HabitanteContexto> options):base(options)
        {
    }
    public DbSet<Habitante> Habitantes {get; set;}
    }
}
