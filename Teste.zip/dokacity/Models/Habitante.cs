namespace dokacity.Models
{
    public class Habitante
    {
        public int Id { get; set; }

        public string Nome { get; set; }

        public string Sobrenome { get; set; }

        public int Idade { get; set; }

        public string Sexo { get; set; }
    }
}