using Microsoft.EntityFrameworkCore;

namespace CrudTabelas.Models
{
    public class EscolaContexto : DbContext
    {
        public EscolaContexto(DbContextOptions<EscolaContexto> options) :base(options)
        	{

        	}
        	public DbSet<Aluno> Alunos {get; set;}
            public DbSet<Professor> Professores {get; set;}
        
    
   	 
    }
}