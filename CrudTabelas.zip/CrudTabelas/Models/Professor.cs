namespace CrudTabelas.Models
{
    public class Professor
    {
        public int Id { get; set; }
        public int Matricula { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        
    }
}